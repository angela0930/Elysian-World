---
navigation:
    title: ExtendedAE 介紹
    position: 60
---

# 擴充你的 AE 設備！

《ExtendedAE》將一些來自 1.7.10/1.12.2 AE 的功能帶來新版本 AE。

[ExtendedAE GitHub](https://github.com/GlodBlock/ExtendedAE) 

## 擴充裝置
<CategoryIndex category="extended devices"></CategoryIndex>

## 擴充物品
<CategoryIndex category="extended items"></CategoryIndex>
