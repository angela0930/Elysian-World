---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME 標籤輸出匯流排
    icon: expatternprovider:tag_export_bus
categories:
- extended devices
item_ids:
- expatternprovider:tag_export_bus
---

# ME 標籤輸出匯流排

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_export_bus.snbt"></ImportStructure>
</GameScene>

ME 標籤輸出匯流排是能以物品，或流體標籤篩選的 <ItemLink id="ae2:export_bus" />。

其篩選規則如同：<ItemLink id="expatternprovider:tag_storage_bus" />。

