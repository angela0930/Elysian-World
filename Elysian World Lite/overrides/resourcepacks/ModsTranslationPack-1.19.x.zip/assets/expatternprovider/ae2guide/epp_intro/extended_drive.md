---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME 擴充驅動器
    icon: expatternprovider:ex_drive
categories:
- extended devices
item_ids:
- expatternprovider:ex_drive
---

# ME 擴充驅動器

<Row gap="20">
<BlockImage id="expatternprovider:ex_drive" scale="8"></BlockImage>
</Row>

ME 擴充驅動器是能夠儲存更多單元的 <ItemLink id="ae2:drive" /> 。其最多可以安裝 20 個儲存單元。
