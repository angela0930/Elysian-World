---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME 擴充介面
    icon: expatternprovider:ex_interface
categories:
- extended devices
item_ids:
- expatternprovider:ex_interface
- expatternprovider:ex_interface_part
---

# ME 擴充介面

<Row gap="20">
<BlockImage id="expatternprovider:ex_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_interface.snbt"></ImportStructure>
</GameScene>
</Row>

ME 擴充介面是擁有更多設定欄位的 <ItemLink id="ae2:interface" />。

*我真的需要這東西嗎？*

![EIGui](../pic/ei_gui.png)
