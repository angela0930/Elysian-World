---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME 擴充 IO 埠
    icon: expatternprovider:ex_io_port
categories:
- extended devices
item_ids:
- expatternprovider:ex_io_port
---

# ME 擴充 IO 埠

<Row gap="20">
<BlockImage id="expatternprovider:ex_io_port" p:powered="true" scale="8"></BlockImage>
</Row>

ME 擴充 IO 埠的運作速度，是普通 <ItemLink id="ae2:io_port" /> 的 8 倍快。

相比於普通版本，ME 擴充 IO 埠還擁有更多升級欄位。
